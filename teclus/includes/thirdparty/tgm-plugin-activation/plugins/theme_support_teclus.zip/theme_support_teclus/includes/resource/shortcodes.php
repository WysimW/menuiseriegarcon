<?php
$bunch_sc = array();

$bunch_sc['bunch_innovative_architects']	=	array(
				"name" => __("Innovative", BUNCH_NAME),
				"base" => "bunch_innovative_architects",
				"class" => "",
				"category" => __('Teclus', BUNCH_NAME),
				"icon" => 'fa-briefcase' ,
				'description' => __('Show Why innovative architects', BUNCH_NAME),
				"params" => array(
					
					array(
					   "type" => "textfield",
					   "holder" => "div",
					   "class" => "",
					   "heading" => __('Title', BUNCH_NAME ),
					   "param_name" => "title",
					   "description" => __('Enter section Title', BUNCH_NAME )
					),
					array(
					   "type" => "textfield",
					   "holder" => "div",
					   "class" => "",
					   "heading" => __('Sub Title', BUNCH_NAME ),
					   "param_name" => "sub_title",
					   "description" => __('Enter section Sub Title', BUNCH_NAME )
					),
					array(
					   "type" => "textarea",
					   "holder" => "div",
					   "class" => "",
					   "heading" => __('Text', BUNCH_NAME ),
					   "param_name" => "text",
					   "description" => __('Enter the text', BUNCH_NAME )
					),
					array(
					   "type" => "textarea",
					   "holder" => "div",
					   "class" => "",
					   "heading" => __('Text2', BUNCH_NAME ),
					   "param_name" => "text2",
					   "description" => __('Enter section text', BUNCH_NAME )
					),
				)
			);
				
$bunch_sc['bunch_architects_services']	=	array(
				"name" => __("Architect Services", BUNCH_NAME),
				"base" => "bunch_architects_services",
				"class" => "",
				"category" => __('Teclus', BUNCH_NAME),
				"icon" => 'fa-briefcase' ,
				'description' => __('Show architects services', BUNCH_NAME),
				"params" => array(
					
					array(
					   "type" => "textfield",
					   "holder" => "div",
					   "class" => "",
					   "heading" => __('Title', BUNCH_NAME ),
					   "param_name" => "title",
					   "description" => __('Enter section Title', BUNCH_NAME )
					),
					array(
					   "type" => "textarea",
					   "holder" => "div",
					   "class" => "",
					   "heading" => __("Features Text", BUNCH_NAME),
					   "param_name" => "feature_str",
					   "description" => __("Enter the Section Features to show.", BUNCH_NAME)
					),
					array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Button Link', BUNCH_NAME ),
						   "param_name" => "btn_link",
						   "description" => __('Enter the button link', BUNCH_NAME )
						),
						
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('btn_text', BUNCH_NAME ),
						   "param_name" => "btn_text",
						   "description" => __('Enter text', BUNCH_NAME )
						),
					)
				);			
				
$bunch_sc['bunch_services_feature']	=	array(
					"name" => __("Services Feature", BUNCH_NAME),
					"base" => "bunch_services_feature",
					"class" => "",
					"category" => __('Teclus', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show services.', BUNCH_NAME),
					"params" => array(
					   	
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text Limit', BUNCH_NAME ),
						   "param_name" => "text_limit",
						   "description" => __('Enter Number of Text Limit to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', BUNCH_NAME ),
						   "param_name" => "num",
						   "description" => __('Enter Number of Slides to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Category', BUNCH_NAME ),
						   "param_name" => "cat",
						   "value" => array_flip( (array)bunch_get_categories( array( 'taxonomy' => 'services_category', 'hide_empty' => FALSE ), true ) ),
						   "description" => __( 'Choose Category.', BUNCH_NAME )
						),
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => __("Order By", BUNCH_NAME),
							"param_name" => "sort",
							'value' => array_flip( array('select'=>__('Select Options', BUNCH_NAME),'date'=>__('Date', BUNCH_NAME),'title'=>__('Title', BUNCH_NAME) ,'name'=>__('Name', BUNCH_NAME) ,'author'=>__('Author', BUNCH_NAME),'comment_count' =>__('Comment Count', BUNCH_NAME),'random' =>__('Random', BUNCH_NAME) ) ),   
							"description" => __("Enter the sorting order.", BUNCH_NAME)
						),
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => __("Order", BUNCH_NAME),
							"param_name" => "order",
							'value' => array_flip(array('select'=>__('Select Options', BUNCH_NAME),'ASC'=>__('Ascending', BUNCH_NAME),'DESC'=>__('Descending', BUNCH_NAME) ) ),   
							"description" => __("Enter the sorting order.", BUNCH_NAME)
						),
					)
				);				
$bunch_sc['bunch_our_portfolio']	=	array(
					"name" => __("Our Portfoio", BUNCH_NAME),
					"base" => "bunch_our_portfolio",
					"class" => "",
					"category" => __('Teclus', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Portfolio.', BUNCH_NAME),
					"params" => array(
					   	
						array(
					   "type" => "textfield",
					   "holder" => "div",
					   "class" => "",
					   "heading" => __('Title', BUNCH_NAME ),
					   "param_name" => "title",
					   "description" => __('Enter section Title', BUNCH_NAME )
					),
					array(
					   "type" => "textarea",
					   "holder" => "div",
					   "class" => "",
					   "heading" => __('Text', BUNCH_NAME ),
					   "param_name" => "text",
					   "description" => __('Enter the text', BUNCH_NAME )
					),
						
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text Limit', BUNCH_NAME ),
						   "param_name" => "text_limit",
						   "description" => __('Enter Number of Text Limit to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', BUNCH_NAME ),
						   "param_name" => "num",
						   "description" => __('Enter Number of Slides to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Category', BUNCH_NAME ),
						   "param_name" => "cat",
						   "value" => array_flip( (array)bunch_get_categories( array( 'taxonomy' => 'gallery_category', 'hide_empty' => FALSE ), true ) ),
						   "description" => __( 'Choose Category.', BUNCH_NAME )
						),
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => __("Order By", BUNCH_NAME),
							"param_name" => "sort",
							'value' => array_flip( array('select'=>__('Select Options', BUNCH_NAME),'date'=>__('Date', BUNCH_NAME),'title'=>__('Title', BUNCH_NAME) ,'name'=>__('Name', BUNCH_NAME) ,'author'=>__('Author', BUNCH_NAME),'comment_count' =>__('Comment Count', BUNCH_NAME),'random' =>__('Random', BUNCH_NAME) ) ),   
							"description" => __("Enter the sorting order.", BUNCH_NAME)
						),
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => __("Order", BUNCH_NAME),
							"param_name" => "order",
							'value' => array_flip(array('select'=>__('Select Options', BUNCH_NAME),'ASC'=>__('Ascending', BUNCH_NAME),'DESC'=>__('Descending', BUNCH_NAME) ) ),   
							"description" => __("Enter the sorting order.", BUNCH_NAME)
						),
					)
				);			
				
$bunch_sc['bunch_our_blog']	=	array(
					"name" => __("Blog Posts", BUNCH_NAME),
					"base" => "bunch_our_blog",
					"class" => "",
					"category" => __('Teclus', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Blog Posts.', BUNCH_NAME),
					"params" => array(
					   	
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter title to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text', BUNCH_NAME ),
						   "param_name" => "text",
						   "description" => __('Enter text.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', BUNCH_NAME ),
						   "param_name" => "num",
						   "description" => __('Enter Number of posts to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text Limit', BUNCH_NAME ),
						   "param_name" => "text_limit",
						   "description" => __('Enter text limit for posts to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Category', BUNCH_NAME ),
						   "param_name" => "cat",
						   "value" => array_flip( (array)bunch_get_categories( array( 'taxonomy' => 'category', 'hide_empty' => FALSE ), true ) ),
						   "description" => __( 'Choose Category.', BUNCH_NAME )
						),
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => __("Order By", BUNCH_NAME),
							"param_name" => "sort",
							'value' => array_flip( array('select'=>__('Select Options', BUNCH_NAME),'date'=>__('Date', BUNCH_NAME),'title'=>__('Title', BUNCH_NAME) ,'name'=>__('Name', BUNCH_NAME) ,'author'=>__('Author', BUNCH_NAME),'comment_count' =>__('Comment Count', BUNCH_NAME),'random' =>__('Random', BUNCH_NAME) ) ),   
							"description" => __("Enter the sorting order.", BUNCH_NAME)
						),
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => __("Order", BUNCH_NAME),
							"param_name" => "order",
							'value' => array_flip(array('select'=>__('Select Options', BUNCH_NAME),'ASC'=>__('Ascending', BUNCH_NAME),'DESC'=>__('Descending', BUNCH_NAME) ) ),   
							"description" => __("Enter the sorting order.", BUNCH_NAME)
						),
					)
				);				
$bunch_sc['bunch_contact_us']	=	array(
					"name" => __("contact us", BUNCH_NAME),
					"base" => "bunch_contact_us",
					"class" => "",
					"category" => __('Teclus', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show the contact us', BUNCH_NAME),
					"params" => array(
					   	
					 	array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter section title', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Address', BUNCH_NAME ),
						   "param_name" => "address",
						   "description" => __('Enter the address', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Phone No', BUNCH_NAME ),
						   "param_name" => "phone_no",
						   "description" => __('Enter the phone number', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Email Address', BUNCH_NAME ),
						   "param_name" => "email",
						   "description" => __('Enter the email', BUNCH_NAME )
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text', BUNCH_NAME ),
						   "param_name" => "text",
						   "description" => __('Enter the text', BUNCH_NAME )
						),
						array(
						   "type" => "textarea_raw_html",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Contact Form 7 Two', BUNCH_NAME ),
						   "param_name" => "contact_form_two",
						   "description" => __('Show Contact Form 7 Two.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Lat', BUNCH_NAME ),
						   "param_name" => "lat",
						   "description" => __('show Lat.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Long', BUNCH_NAME ),
						   "param_name" => "long",
						   "description" => __('Show Long.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Mark Lat', BUNCH_NAME ),
						   "param_name" => "mark_lat",
						   "description" => __('Show Mark Lat.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Mark Long', BUNCH_NAME ),
						   "param_name" => "mark_long",
						   "description" => __('Show Mark Long.', BUNCH_NAME )
						),
						
					)
				);				
$bunch_sc['bunch_services_slider']	=	array(
					"name" => __("Service Slider", BUNCH_NAME),
					"base" => "bunch_services_slider",
					"class" => "",
					"category" => __('Teclus', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show service slider.', BUNCH_NAME),
					"params" => array(
					   	
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text Limit', BUNCH_NAME ),
						   "param_name" => "text_limit",
						   "description" => __('Enter Number of Text Limit to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', BUNCH_NAME ),
						   "param_name" => "num",
						   "description" => __('Enter Number of Slides to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Category', BUNCH_NAME ),
						   "param_name" => "cat",
						   "value" => array_flip( (array)bunch_get_categories( array( 'taxonomy' => 'services_category', 'hide_empty' => FALSE ), true ) ),
						   "description" => __( 'Choose Category.', BUNCH_NAME )
						),
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => __("Order By", BUNCH_NAME),
							"param_name" => "sort",
							'value' => array_flip( array('select'=>__('Select Options', BUNCH_NAME),'date'=>__('Date', BUNCH_NAME),'title'=>__('Title', BUNCH_NAME) ,'name'=>__('Name', BUNCH_NAME) ,'author'=>__('Author', BUNCH_NAME),'comment_count' =>__('Comment Count', BUNCH_NAME),'random' =>__('Random', BUNCH_NAME) ) ),   
							"description" => __("Enter the sorting order.", BUNCH_NAME)
						),
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => __("Order", BUNCH_NAME),
							"param_name" => "order",
							'value' => array_flip(array('select'=>__('Select Options', BUNCH_NAME),'ASC'=>__('Ascending', BUNCH_NAME),'DESC'=>__('Descending', BUNCH_NAME) ) ),   
							"description" => __("Enter the sorting order.", BUNCH_NAME)
						),
						array(
						   "type" => "attach_image",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Image", BUNCH_NAME),
						   "param_name" => "image",
						   'value' => '',
						   "description" => __("Enter the Image url", BUNCH_NAME)
						),
					)
				);
$bunch_sc['bunch_our_team']	=	array(
					"name" => __("Our Team", BUNCH_NAME),
					"base" => "bunch_our_team",
					"class" => "",
					"category" => __('Teclus', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Team.', BUNCH_NAME),
					"params" => array(
					   	
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter section Title', BUNCH_NAME )
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text', BUNCH_NAME ),
						   "param_name" => "text",
						   "description" => __('Enter the text', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Button Link', BUNCH_NAME ),
						   "param_name" => "btn_link",
						   "description" => __('Enter the button link', BUNCH_NAME )
						),
						
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('btn_text', BUNCH_NAME ),
						   "param_name" => "btn_text",
						   "description" => __('Enter text', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text Limit', BUNCH_NAME ),
						   "param_name" => "text_limit",
						   "description" => __('Enter Number of Text Limit to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', BUNCH_NAME ),
						   "param_name" => "num",
						   "description" => __('Enter Number of Slides to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Category', BUNCH_NAME ),
						   "param_name" => "cat",
						   "value" => array_flip( (array)bunch_get_categories( array( 'taxonomy' => 'team_category', 'hide_empty' => FALSE ), true ) ),
						   "description" => __( 'Choose Category.', BUNCH_NAME )
						),
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => __("Order By", BUNCH_NAME),
							"param_name" => "sort",
							'value' => array_flip( array('select'=>__('Select Options', BUNCH_NAME),'date'=>__('Date', BUNCH_NAME),'title'=>__('Title', BUNCH_NAME) ,'name'=>__('Name', BUNCH_NAME) ,'author'=>__('Author', BUNCH_NAME),'comment_count' =>__('Comment Count', BUNCH_NAME),'random' =>__('Random', BUNCH_NAME) ) ),   
							"description" => __("Enter the sorting order.", BUNCH_NAME)
						),
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => __("Order", BUNCH_NAME),
							"param_name" => "order",
							'value' => array_flip(array('select'=>__('Select Options', BUNCH_NAME),'ASC'=>__('Ascending', BUNCH_NAME),'DESC'=>__('Descending', BUNCH_NAME) ) ),   
							"description" => __("Enter the sorting order.", BUNCH_NAME)
						),
					)
				);				
$bunch_sc['bunch_our_clients']	=	array(
					"name" => __("Our Clients", BUNCH_NAME),
					"base" => "bunch_our_clients",
					"class" => "",
					"category" => __('Teclus', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show clients.', BUNCH_NAME),
					"params" => array(
					   	
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Description', BUNCH_NAME ),
						   "param_name" => "description",
						   "description" => __('Enter the description for self help.', BUNCH_NAME )
						),
						array(
						   "type" => "checkbox",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('No Padding Bottom', BUNCH_NAME ),
						   "param_name" => "style_two",
						   'value' => array(__('No Padding Bottom', BUNCH_NAME )=>true),
						   "description" => __('Choose whether you want to Remove padding of section.', BUNCH_NAME )
						),
					)
				);
$bunch_sc['bunch_our_services']	=	array(
					"name" => __("Our Services", BUNCH_NAME),
					"base" => "bunch_our_services",
					"class" => "",
					"category" => __('Teclus', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Our Services.', BUNCH_NAME),
					"params" => array(
					   	
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter section Title', BUNCH_NAME )
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text', BUNCH_NAME ),
						   "param_name" => "text",
						   "description" => __('Enter the text', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text Limit', BUNCH_NAME ),
						   "param_name" => "text_limit",
						   "description" => __('Enter Number of Text Limit to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', BUNCH_NAME ),
						   "param_name" => "num",
						   "description" => __('Enter Number of Slides to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Category', BUNCH_NAME ),
						   "param_name" => "cat",
						   "value" => array_flip( (array)bunch_get_categories( array( 'taxonomy' => 'services_category', 'hide_empty' => FALSE ), true ) ),
						   "description" => __( 'Choose Category.', BUNCH_NAME )
						),
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => __("Order By", BUNCH_NAME),
							"param_name" => "sort",
							'value' => array_flip( array('select'=>__('Select Options', BUNCH_NAME),'date'=>__('Date', BUNCH_NAME),'title'=>__('Title', BUNCH_NAME) ,'name'=>__('Name', BUNCH_NAME) ,'author'=>__('Author', BUNCH_NAME),'comment_count' =>__('Comment Count', BUNCH_NAME),'random' =>__('Random', BUNCH_NAME) ) ),   
							"description" => __("Enter the sorting order.", BUNCH_NAME)
						),
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => __("Order", BUNCH_NAME),
							"param_name" => "order",
							'value' => array_flip(array('select'=>__('Select Options', BUNCH_NAME),'ASC'=>__('Ascending', BUNCH_NAME),'DESC'=>__('Descending', BUNCH_NAME) ) ),   
							"description" => __("Enter the sorting order.", BUNCH_NAME)
						),
					)
				);				
$bunch_sc['bunch_planning_architects']	=	array(
					"name" => __("Our Planning", BUNCH_NAME),
					"base" => "bunch_planning_architects",
					"class" => "",
					"category" => __('Teclus', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Planning Architects.', BUNCH_NAME),
					"params" => array(
					   	
						array(
						   "type" => "attach_image",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Image", BUNCH_NAME),
						   "param_name" => "image",
						   'value' => '',
						   "description" => __("Enter the Image url", BUNCH_NAME)
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Overlay Title', BUNCH_NAME ),
						   "param_name" => "overlay_title",
						   "description" => __('Enter overlaytitle', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Overlay Text', BUNCH_NAME ),
						   "param_name" => "overlay_text",
						   "description" => __('Enter the Overylay Text', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter section Title', BUNCH_NAME )
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text', BUNCH_NAME ),
						   "param_name" => "text",
						   "description" => __('Enter the text', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Button Link', BUNCH_NAME ),
						   "param_name" => "btn_link",
						   "description" => __('Enter the button link', BUNCH_NAME )
						),
						
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('btn_text', BUNCH_NAME ),
						   "param_name" => "btn_text",
						   "description" => __('Enter text', BUNCH_NAME )
						),				
					)
				);	
$bunch_sc['bunch_we_do_tabs']	=	array(
					"name" => __("We Do Tabs", BUNCH_NAME),
					"base" => "bunch_we_do_tabs",
					"class" => "",
					"category" => __('Teclus', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Tabs.', BUNCH_NAME),
					"params" => array(
					   	array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter section Title', BUNCH_NAME )
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text', BUNCH_NAME ),
						   "param_name" => "text",
						   "description" => __('Enter the text', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', BUNCH_NAME ),
						   "param_name" => "num",
						   "description" => __('Enter Number of Slides to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Category', BUNCH_NAME ),
						   "param_name" => "cat",
						   "value" => array_flip( (array)bunch_get_categories( array( 'taxonomy' => 'services_category', 'hide_empty' => FALSE ), true ) ),
						   "description" => __( 'Choose Category.', BUNCH_NAME )
						),
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => __("Order By", BUNCH_NAME),
							"param_name" => "sort",
							'value' => array_flip( array('select'=>__('Select Options', BUNCH_NAME),'date'=>__('Date', BUNCH_NAME),'title'=>__('Title', BUNCH_NAME) ,'name'=>__('Name', BUNCH_NAME) ,'author'=>__('Author', BUNCH_NAME),'comment_count' =>__('Comment Count', BUNCH_NAME),'random' =>__('Random', BUNCH_NAME) ) ),   
							"description" => __("Enter the sorting order.", BUNCH_NAME)
						),
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => __("Order", BUNCH_NAME),
							"param_name" => "order",
							'value' => array_flip(array('select'=>__('Select Options', BUNCH_NAME),'ASC'=>__('Ascending', BUNCH_NAME),'DESC'=>__('Descending', BUNCH_NAME) ) ),   
							"description" => __("Enter the sorting order.", BUNCH_NAME)
						),		
					)
				);
$bunch_sc['bunch_gallery_carousel']	=	array(
					"name" => __("Gallery_Carousel", BUNCH_NAME),
					"base" => "bunch_gallery_carousel",
					"class" => "",
					"category" => __('Teclus', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Gallery Carousel.', BUNCH_NAME),
					"params" => array(	
					
					array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', BUNCH_NAME ),
						   "param_name" => "num",
						   "description" => __('Enter Number of Slides to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Category', BUNCH_NAME ),
						   "param_name" => "cat",
						   "value" => array_flip( (array)bunch_get_categories( array( 'taxonomy' => 'gallery_category', 'hide_empty' => FALSE ), true ) ),
						   "description" => __( 'Choose Category.', BUNCH_NAME )
						),
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => __("Order By", BUNCH_NAME),
							"param_name" => "sort",
							'value' => array_flip( array('select'=>__('Select Options', BUNCH_NAME),'date'=>__('Date', BUNCH_NAME),'title'=>__('Title', BUNCH_NAME) ,'name'=>__('Name', BUNCH_NAME) ,'author'=>__('Author', BUNCH_NAME),'comment_count' =>__('Comment Count', BUNCH_NAME),'random' =>__('Random', BUNCH_NAME) ) ),   
							"description" => __("Enter the sorting order.", BUNCH_NAME)
						),
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => __("Order", BUNCH_NAME),
							"param_name" => "order",
							'value' => array_flip(array('select'=>__('Select Options', BUNCH_NAME),'ASC'=>__('Ascending', BUNCH_NAME),'DESC'=>__('Descending', BUNCH_NAME) ) ),   
							"description" => __("Enter the sorting order.", BUNCH_NAME)
						),		
					)
				);			
$bunch_sc['bunch_our_history']	=	array(
					"name" => __("Our History", BUNCH_NAME),
					"base" => "bunch_our_history",
					"class" => "",
					"category" => __('Teclus', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Company History.', BUNCH_NAME),
					"params" => array(
					   	array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter section Title', BUNCH_NAME )
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text', BUNCH_NAME ),
						   "param_name" => "text",
						   "description" => __('Enter the text', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', BUNCH_NAME ),
						   "param_name" => "num",
						   "description" => __('Enter Number of Slides to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Category', BUNCH_NAME ),
						   "param_name" => "cat",
						   "value" => array_flip( (array)bunch_get_categories( array( 'taxonomy' => 'history_category', 'hide_empty' => FALSE ), true ) ),
						   "description" => __( 'Choose Category.', BUNCH_NAME )
						),
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => __("Order By", BUNCH_NAME),
							"param_name" => "sort",
							'value' => array_flip( array('select'=>__('Select Options', BUNCH_NAME),'date'=>__('Date', BUNCH_NAME),'title'=>__('Title', BUNCH_NAME) ,'name'=>__('Name', BUNCH_NAME) ,'author'=>__('Author', BUNCH_NAME),'comment_count' =>__('Comment Count', BUNCH_NAME),'random' =>__('Random', BUNCH_NAME) ) ),   
							"description" => __("Enter the sorting order.", BUNCH_NAME)
						),
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => __("Order", BUNCH_NAME),
							"param_name" => "order",
							'value' => array_flip(array('select'=>__('Select Options', BUNCH_NAME),'ASC'=>__('Ascending', BUNCH_NAME),'DESC'=>__('Descending', BUNCH_NAME) ) ),   
							"description" => __("Enter the sorting order.", BUNCH_NAME)
						),		
					)
				);
$bunch_sc['bunch_skill_facts']	=	array(
						"name" => __("Skill Facts", BUNCH_NAME),
						"base" => "bunch_skill_facts",
						"class" => "",
						"category" => __('Teclus', BUNCH_NAME),
						"icon" => 'icon-wpb-layer-shape-text' ,
						"as_parent" => array('only' => 'bunch_skill_fact'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
						"content_element" => true,
						"show_settings_on_create" => false,
						'description' => __('Add Skill Facts.', BUNCH_NAME),
						"params" => array(
									array(
									   "type" => "textfield",
									   "holder" => "div",
									   "class" => "",
									   "heading" => __("Title", BUNCH_NAME),
									   "param_name" => "title",
									   "description" => __("Enter the Title.", BUNCH_NAME)
									),
									array(
									   "type" => "attach_image",
									   "holder" => "div",
									   "class" => "",
									   "heading" => __("Image", BUNCH_NAME),
									   "param_name" => "img",
									   'value' => '',
									   "description" => __("Enter the Image url", BUNCH_NAME)
									),
						
								),
							
							"js_view" => 'VcColumnView'
						);
$bunch_sc['bunch_skill_fact']	=	array(
						"name" => __("Skill Fact", BUNCH_NAME),
						"base" => "bunch_skill_fact",
						"class" => "",
						"category" => __('Teclus', BUNCH_NAME),
						"icon" => 'icon-wpb-layer-shape-text' ,
						"as_child" => array('only' => 'bunch_skill_facts'),// Use only|except attributes to limit child shortcodes (separate multiple values with comma)
						"content_element" => true,
						"show_settings_on_create" => true,
						'description' => __('Add Skill Fact.', BUNCH_NAME),
						"params" => array(
							
							array(
							   "type" => "textfield",
							   "holder" => "div",
							   "class" => "",
							   "heading" => __("Title", BUNCH_NAME),
							   "param_name" => "title",
							   "description" => __("Enter the title to show.", BUNCH_NAME)
							),
							array(
							   "type" => "textfield",
							   "holder" => "div",
							   "class" => "",
							   "heading" => __("Number(%)", BUNCH_NAME),
							   "param_name" => "num",
							   "description" => __("Enter the % Number show.", BUNCH_NAME)
							),
						),
					);
$bunch_sc['bunch_innovative_architects2']	=	array(
						"name" => __("Innovatvie Architect", BUNCH_NAME),
						"base" => "bunch_innovative_architects2",
						"class" => "",
						"category" => __('Teclus', BUNCH_NAME),
						"icon" => 'icon-wpb-layer-shape-text' ,
						"as_parent" => array('only' => 'bunch_innovative_architect2'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
						"content_element" => true,
						"show_settings_on_create" => false,
						'description' => __('Add innovative architects2.', BUNCH_NAME),
						"params" => array(
									array(
									   "type" => "textfield",
									   "holder" => "div",
									   "class" => "",
									   "heading" => __("Title", BUNCH_NAME),
									   "param_name" => "title",
									   "description" => __("Enter the Title.", BUNCH_NAME)
									),
									array(
									   "type" => "textfield",
									   "holder" => "div",
									   "class" => "",
									   "heading" => __("Text", BUNCH_NAME),
									   "param_name" => "text",
									   "description" => __("Enter the Text.", BUNCH_NAME)
									),
						
								),
							
							"js_view" => 'VcColumnView'
						);
$bunch_sc['bunch_innovative_architect2']	=	array(
						"name" => __("Innovative Architect2", BUNCH_NAME),
						"base" => "bunch_innovative_architect2",
						"class" => "",
						"category" => __('Teclus', BUNCH_NAME),
						"icon" => 'icon-wpb-layer-shape-text' ,
						"as_child" => array('only' => 'bunch_innovative_architects2'),// Use only|except attributes to limit child shortcodes (separate multiple values with comma)
						"content_element" => true,
						"show_settings_on_create" => true,
						'description' => __('Add Innovative Architect2.', BUNCH_NAME),
						"params" => array(
							array(
							   "type" => "dropdown",
							   "holder" => "div",
							   "class" => "",
							   "heading" => __("Icon", BUNCH_NAME),
							   "param_name" => "icon",
							   "value" => (array)vp_get_fontawesome_icons(),
							   "description" => __("Choose Icon for Process", BUNCH_NAME)
							),
							array(
							   "type" => "textfield",
							   "holder" => "div",
							   "class" => "",
							   "heading" => __("Title", BUNCH_NAME),
							   "param_name" => "title",
							   "description" => __("Enter the title to show.", BUNCH_NAME)
							),
							array(
							   "type" => "textfield",
							   "holder" => "div",
							   "class" => "",
							   "heading" => __("Text", BUNCH_NAME),
							   "param_name" => "text",
							   "description" => __("Enter the Text to show.", BUNCH_NAME)
							),
						),
					);
$bunch_sc['bunch_funfacts']	=	array(
						"name" => __("Funfacts", BUNCH_NAME),
						"base" => "bunch_funfacts",
						"class" => "",
						"category" => __('Teclus', BUNCH_NAME),
						"icon" => 'icon-wpb-layer-shape-text' ,
						"as_parent" => array('only' => 'bunch_funfact'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
						"content_element" => true,
						"show_settings_on_create" => false,
						'description' => __('Add Funfacts.', BUNCH_NAME),
						"params" => array(
									array(
									   "type" => "textfield",
									   "holder" => "div",
									   "class" => "",
									   "heading" => __("Title", BUNCH_NAME),
									   "param_name" => "title",
									   "description" => __("Enter the Title.", BUNCH_NAME)
									),
									array(
									   "type" => "textfield",
									   "holder" => "div",
									   "class" => "",
									   "heading" => __("Sub Title", BUNCH_NAME),
									   "param_name" => "sub_title",
									   "description" => __("Enter the SubTitle.", BUNCH_NAME)
									),
									array(
									   "type" => "textfield",
									   "holder" => "div",
									   "class" => "",
									   "heading" => __("Text", BUNCH_NAME),
									   "param_name" => "text",
									   "description" => __("Enter the Text.", BUNCH_NAME)
									),
						
								),
							
							"js_view" => 'VcColumnView'
						);
$bunch_sc['bunch_funfact']	=	array(
						"name" => __("Funfact", BUNCH_NAME),
						"base" => "bunch_funfact",
						"class" => "",
						"category" => __('Teclus', BUNCH_NAME),
						"icon" => 'icon-wpb-layer-shape-text' ,
						"as_child" => array('only' => 'bunch_funfacts'),// Use only|except attributes to limit child shortcodes (separate multiple values with comma)
						"content_element" => true,
						"show_settings_on_create" => true,
						'description' => __('Add funfact.', BUNCH_NAME),
						"params" => array(
							
							array(
							   "type" => "textfield",
							   "holder" => "div",
							   "class" => "",
							   "heading" => __("Title", BUNCH_NAME),
							   "param_name" => "title",
							   "description" => __("Enter the title to show.", BUNCH_NAME)
							),
							array(
							   "type" => "textfield",
							   "holder" => "div",
							   "class" => "",
							   "heading" => __("Start Number", BUNCH_NAME),
							   "param_name" => "start_num",
							   "description" => __("Enter the start number.", BUNCH_NAME)
							),
							array(
							   "type" => "textfield",
							   "holder" => "div",
							   "class" => "",
							   "heading" => __("Number", BUNCH_NAME),
							   "param_name" => "num",
							   "description" => __("Enter the start number.", BUNCH_NAME)
							),
						),
					);					
$bunch_sc['bunch_portfolio_mixitup']	=	array(
					"name" => __("Portfolio Mixitup", BUNCH_NAME),
					"base" => "bunch_portfolio_mixitup",
					"class" => "",
					"category" => __('Teclus', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Portfolio Mixitup.', BUNCH_NAME),
					"params" => array(
					   	
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter Number of Title to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text Limit', BUNCH_NAME ),
						   "param_name" => "text_limit",
						   "description" => __('Enter Number of Text Limit to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', BUNCH_NAME ),
						   "param_name" => "num",
						   "description" => __('Enter Number of Slides to Show.', BUNCH_NAME )
						),
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => __("Order By", BUNCH_NAME),
							"param_name" => "sort",
							'value' => array_flip( array('select'=>__('Select Options', BUNCH_NAME),'date'=>__('Date', BUNCH_NAME),'title'=>__('Title', BUNCH_NAME) ,'name'=>__('Name', BUNCH_NAME) ,'author'=>__('Author', BUNCH_NAME),'comment_count' =>__('Comment Count', BUNCH_NAME),'random' =>__('Random', BUNCH_NAME) ) ),   
							"description" => __("Enter the sorting order.", BUNCH_NAME)
						),
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => __("Order", BUNCH_NAME),
							"param_name" => "order",
							'value' => array_flip(array('select'=>__('Select Options', BUNCH_NAME),'ASC'=>__('Ascending', BUNCH_NAME),'DESC'=>__('Descending', BUNCH_NAME) ) ),   
							"description" => __("Enter the sorting order.", BUNCH_NAME)
						),	
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Excluded Categories ID', BUNCH_NAME ),
						   "param_name" => "exclude_cats",
						   "description" => __('Enter Excluded Categories ID seperated by commas(13,14).', BUNCH_NAME )
						),
					)
				);					
$bunch_sc['bunch_gallery_masonry']	=	array(
					"name" => __("Gallery masonry", BUNCH_NAME),
					"base" => "bunch_gallery_masonry",
					"class" => "",
					"category" => __('Teclus', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Gallery masonry.', BUNCH_NAME),
					"params" => array(	
					
					array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', BUNCH_NAME ),
						   "param_name" => "num",
						   "description" => __('Enter Number of Slides to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text Limit', BUNCH_NAME ),
						   "param_name" => "text_limit",
						   "description" => __('Enter Number of Text Limit to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Excluded Categories ID', BUNCH_NAME ),
						   "param_name" => "exclude_cats",
						   "description" => __('Enter Excluded Categories ID seperated by commas(13,14).', BUNCH_NAME )
						),
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => __("Order By", BUNCH_NAME),
							"param_name" => "sort",
							'value' => array_flip( array('select'=>__('Select Options', BUNCH_NAME),'date'=>__('Date', BUNCH_NAME),'title'=>__('Title', BUNCH_NAME) ,'name'=>__('Name', BUNCH_NAME) ,'author'=>__('Author', BUNCH_NAME),'comment_count' =>__('Comment Count', BUNCH_NAME),'random' =>__('Random', BUNCH_NAME) ) ),   
							"description" => __("Enter the sorting order.", BUNCH_NAME)
						),
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => __("Order", BUNCH_NAME),
							"param_name" => "order",
							'value' => array_flip(array('select'=>__('Select Options', BUNCH_NAME),'ASC'=>__('Ascending', BUNCH_NAME),'DESC'=>__('Descending', BUNCH_NAME) ) ),   
							"description" => __("Enter the sorting order.", BUNCH_NAME)
						),		
					)
				);
$bunch_sc['bunch_portfolio_mixitup_masonry']	=	array(
					"name" => __("Portfolio Mixitup Masonry", BUNCH_NAME),
					"base" => "bunch_portfolio_mixitup_masonry",
					"class" => "",
					"category" => __('Teclus', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Portfolio Mixitup Masonry.', BUNCH_NAME),
					"params" => array(
					   	
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter Number of Title to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text Limit', BUNCH_NAME ),
						   "param_name" => "text_limit",
						   "description" => __('Enter Number of Text Limit to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', BUNCH_NAME ),
						   "param_name" => "num",
						   "description" => __('Enter Number of Slides to Show.', BUNCH_NAME )
						),
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => __("Order By", BUNCH_NAME),
							"param_name" => "sort",
							'value' => array_flip( array('select'=>__('Select Options', BUNCH_NAME),'date'=>__('Date', BUNCH_NAME),'title'=>__('Title', BUNCH_NAME) ,'name'=>__('Name', BUNCH_NAME) ,'author'=>__('Author', BUNCH_NAME),'comment_count' =>__('Comment Count', BUNCH_NAME),'random' =>__('Random', BUNCH_NAME) ) ),   
							"description" => __("Enter the sorting order.", BUNCH_NAME)
						),
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => __("Order", BUNCH_NAME),
							"param_name" => "order",
							'value' => array_flip(array('select'=>__('Select Options', BUNCH_NAME),'ASC'=>__('Ascending', BUNCH_NAME),'DESC'=>__('Descending', BUNCH_NAME) ) ),   
							"description" => __("Enter the sorting order.", BUNCH_NAME)
						),	
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Excluded Categories ID', BUNCH_NAME ),
						   "param_name" => "exclude_cats",
						   "description" => __('Enter Excluded Categories ID seperated by commas(13,14).', BUNCH_NAME )
						),
					)
				);	
$bunch_sc['bunch_blog_two_column']	=	array(
					"name" => __("Blog Posts Two Column", BUNCH_NAME),
					"base" => "bunch_blog_two_column",
					"class" => "",
					"category" => __('Teclus', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Blog Posts Two Column.', BUNCH_NAME),
					"params" => array(
					   	
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', BUNCH_NAME ),
						   "param_name" => "num",
						   "description" => __('Enter Number of posts to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text Limit', BUNCH_NAME ),
						   "param_name" => "text_limit",
						   "description" => __('Enter text limit for posts to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Category', BUNCH_NAME ),
						   "param_name" => "cat",
						   "value" => array_flip( (array)bunch_get_categories( array( 'taxonomy' => 'category', 'hide_empty' => FALSE ), true ) ),
						   "description" => __( 'Choose Category.', BUNCH_NAME )
						),
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => __("Order By", BUNCH_NAME),
							"param_name" => "sort",
							'value' => array_flip( array('select'=>__('Select Options', BUNCH_NAME),'date'=>__('Date', BUNCH_NAME),'title'=>__('Title', BUNCH_NAME) ,'name'=>__('Name', BUNCH_NAME) ,'author'=>__('Author', BUNCH_NAME),'comment_count' =>__('Comment Count', BUNCH_NAME),'random' =>__('Random', BUNCH_NAME) ) ),   
							"description" => __("Enter the sorting order.", BUNCH_NAME)
						),
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => __("Order", BUNCH_NAME),
							"param_name" => "order",
							'value' => array_flip(array('select'=>__('Select Options', BUNCH_NAME),'ASC'=>__('Ascending', BUNCH_NAME),'DESC'=>__('Descending', BUNCH_NAME) ) ),   
							"description" => __("Enter the sorting order.", BUNCH_NAME)
						),
					)
				);
$bunch_sc['bunch_blog_three_column']	=	array(
					"name" => __("Blog Posts Three Column", BUNCH_NAME),
					"base" => "bunch_blog_three_column",
					"class" => "",
					"category" => __('Teclus', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Blog Posts Three Column.', BUNCH_NAME),
					"params" => array(
					   	
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', BUNCH_NAME ),
						   "param_name" => "num",
						   "description" => __('Enter Number of posts to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text Limit', BUNCH_NAME ),
						   "param_name" => "text_limit",
						   "description" => __('Enter text limit for posts to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Category', BUNCH_NAME ),
						   "param_name" => "cat",
						   "value" => array_flip( (array)bunch_get_categories( array( 'taxonomy' => 'category', 'hide_empty' => FALSE ), true ) ),
						   "description" => __( 'Choose Category.', BUNCH_NAME )
						),
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => __("Order By", BUNCH_NAME),
							"param_name" => "sort",
							'value' => array_flip( array('select'=>__('Select Options', BUNCH_NAME),'date'=>__('Date', BUNCH_NAME),'title'=>__('Title', BUNCH_NAME) ,'name'=>__('Name', BUNCH_NAME) ,'author'=>__('Author', BUNCH_NAME),'comment_count' =>__('Comment Count', BUNCH_NAME),'random' =>__('Random', BUNCH_NAME) ) ),   
							"description" => __("Enter the sorting order.", BUNCH_NAME)
						),
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => __("Order", BUNCH_NAME),
							"param_name" => "order",
							'value' => array_flip(array('select'=>__('Select Options', BUNCH_NAME),'ASC'=>__('Ascending', BUNCH_NAME),'DESC'=>__('Descending', BUNCH_NAME) ) ),   
							"description" => __("Enter the sorting order.", BUNCH_NAME)
						),
					)
				);				
$bunch_sc['bunch_google_map']	=	array(
					"name" => __("Google Map", BUNCH_NAME),
					"base" => "bunch_google_map",
					"class" => "",
					"category" => __('Teclus', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Google Map.', BUNCH_NAME),
					"params" => array(	
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Lat', BUNCH_NAME ),
						   "param_name" => "lat",
						   "description" => __('show Lat.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Long', BUNCH_NAME ),
						   "param_name" => "long",
						   "description" => __('Show Long.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Mark Lat', BUNCH_NAME ),
						   "param_name" => "mark_lat",
						   "description" => __('Show Mark Lat.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Mark Long', BUNCH_NAME ),
						   "param_name" => "mark_long",
						   "description" => __('Show Mark Long.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Mark Title', BUNCH_NAME ),
						   "param_name" => "mark_title",
						   "description" => __('Show Mark Title.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Mark Address', BUNCH_NAME ),
						   "param_name" => "mark_address",
						   "description" => __('Show Mark Address.', BUNCH_NAME )
						),
					)
				);
$bunch_sc['bunch_contact_us_form']	=	array(
					"name" => __("Contact Us Form", BUNCH_NAME),
					"base" => "bunch_contact_us_form",
					"class" => "",
					"category" => __('Teclus', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Contact Us Form.', BUNCH_NAME),
					"params" => array(	
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('show Title.', BUNCH_NAME )
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text', BUNCH_NAME ),
						   "param_name" => "text",
						   "description" => __('show The Text.', BUNCH_NAME )
						),
						array(
						   "type" => "textarea_raw_html",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Contact Form 7', BUNCH_NAME ),
						   "param_name" => "contact_form",
						   "description" => __('Show Contact Form 7.', BUNCH_NAME )
						),
					)
				);
$bunch_sc['bunch_contact_us_three']	=	array(
					"name" => __("Contact Us Form Three", BUNCH_NAME),
					"base" => "bunch_contact_us_three",
					"class" => "",
					"category" => __('Teclus', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Contact Us Form Three.', BUNCH_NAME),
					"params" => array(	
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('show Title.', BUNCH_NAME )
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text', BUNCH_NAME ),
						   "param_name" => "text",
						   "description" => __('show The Text.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Lat', BUNCH_NAME ),
						   "param_name" => "lat",
						   "description" => __('show Lat.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Long', BUNCH_NAME ),
						   "param_name" => "long",
						   "description" => __('Show Long.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Mark Lat', BUNCH_NAME ),
						   "param_name" => "mark_lat",
						   "description" => __('Show Mark Lat.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Mark Long', BUNCH_NAME ),
						   "param_name" => "mark_long",
						   "description" => __('Show Mark Long.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Mark Title', BUNCH_NAME ),
						   "param_name" => "mark_title",
						   "description" => __('Show Mark Title.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Mark Address', BUNCH_NAME ),
						   "param_name" => "mark_address",
						   "description" => __('Show Mark Address.', BUNCH_NAME )
						),
						array(
						   "type" => "textarea_raw_html",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Contact Form 7', BUNCH_NAME ),
						   "param_name" => "contact_form_three",
						   "description" => __('Show Contact Form Three.', BUNCH_NAME )
						),
					)
				);				
											

/*----------------------------------------------------------------------------*/
$bunch_sc = apply_filters( '_bunch_shortcodes_array', $bunch_sc );
	
return $bunch_sc;